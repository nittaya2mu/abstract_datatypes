@echo off
cd /d "%~dp0"
start "" "SmartParking.exe"
